## Upgrading from Nock 9 to Nock 10

[Release Tag](https://github.com/nock/nock/releases/tag/v10.0.0)

### Breaking changes

Support for Node < 6 was dropped.

To upgrade Nock, ensure your version of Node is also updated.  
At the time of release, Node 6.x, 8.x, and 9.x were supported.
